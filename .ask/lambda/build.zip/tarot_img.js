module.exports = [
    `https://triviabucket123.s3.amazonaws.com/Freya.png`,
    `https://triviabucket123.s3.amazonaws.com/Thor.png`,
    `https://triviabucket123.s3.amazonaws.com/HangedMan.png`,
    `https://triviabucket123.s3.amazonaws.com/EightOfSwords.png`,
    `https://triviabucket123.s3.amazonaws.com/AceOfCups.png`
];